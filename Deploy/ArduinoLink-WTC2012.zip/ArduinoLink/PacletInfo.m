Paclet[
	Name -> "ArduinoLink",
	Version -> "0.0.2",
	MathematicaVersion -> "8+",
	SystemID -> {"MacOSX-x86-64"},
	Loading -> Automatic,
	Extensions -> {
		{"Documentation", MainPage->"Guides/ArduinoLink"},
		{"Kernel", Root->".", Context->"ArduinoLink`", Symbols->{"ArduinoConnect"}}
	}
]