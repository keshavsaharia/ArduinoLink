(* Mathematica Package *)

(* Created by the Wolfram Workbench Aug 25, 2011 *)

(*  Updated September 24th, 2012
	This is the ArduinoLink package, as of right now it has only been tested on Mac OSX. The Serial I/O functionality
	has been tested on Windows & Linux, however Mac OSX is by far the most robust. There is support for all Arduino boards,
	however only the Arduino Uno and the Arduino Duemilanove have been thoroughly tested.
	
	So far, here's what you can do:
	- Digital Pin I/O
	- Analog Pin I/O
	- Serial communication
	- Code generation
	- control servo motors
	
	Happy prototyping!
	
	-Keshav Saharia
	 Wolfram Research Inc.
*)

BeginPackage["ArduinoLink`", {"SymbolicC`"}] 

InitializeArduinoLink::usage = "Ensures that the Arduino libraries that ArduinoLink compiles against are compiled.";

(****************************************************************************************************
 *	Interface to hardware																			*
 ****************************************************************************************************)
 
Arduino::usage = "Arduino[port] is a symbolic representation of an Arduino device connected to the specified port.";
ArduinoQ::usage = "ArduinoQ[ device ] returns True if the device is a symbolic representation of a connected Arduino device.";

LinkArduino::usage = "LinkArduino[] returns a List of symbolic representations of all connected Arduino devices.\n" <>
					"LinkArduino[port] returns a symbolic representation of the Arduino device connected to the specified port.";

ArduinoUpload::usage = "ArduinoUpload[ device, { setup }, { loop } ] \
					 first runs the setup instructions, then the loop instructions, on the given Arduino device";
ArduinoUpload::usage = "ArduinoUpload[ device, { function init }, { setup }, { loop } ] \
					 initializes the functions and state information, then runs the setup instructions and the loop instructions on the given Arduino device";

$SupportedArduino::usage = "$SupportedArduino returns a list of Arduino boards that are supported by ArduinoLink.";
$SupportedMicrocontroller::usage = "$SupportedMicrocontroller returns a list of AVR microcontrollers that are supported by ArduinoLink.";

(****************************************************************************************************
 *	Code generation functions 																		*
 ****************************************************************************************************)

ArduinoRepeat::usage = "ArduinoRepeat[ var, {start, end}, block ] iterates the variable var over the range [start, end] when running the code block.";
ArduinoNamePin::usage = "ArduinoNamePin[ pin, name ] gives the specified pin a textual alias on an Arduino device.";
ArduinoSetPin::usage = "ArduinoSetPin[ pin, I/O type ] sets the specified pin to the digital I/O type for an Arduino device."; 

DigitalBlink::usage = "DigitalBlink[ pin, time ] switches the pin to High, then Low, over the given time interval, on an Arduino device.";
AnalogSignal::usage = "AnalogSignal[ pin, function ] generates the given function on the given analog pin on an Arduino device."; 

(****************************************************************************************************
 *	Analog and Digital I/O 																			*
 ****************************************************************************************************)

DigitalWrite::usage = "DigitalWrite[ pin, status ] writes the digital status to the given pin on an Arduino device.";
DigitalRead::usage = "DigitalRead[ pin ] returns the digital pin readout from the specified pin on an Arduino device.";
AnalogWrite::usage = "AnalogWrite[ pin, status ] writes the analog status to the given pin on an Arduino device.";
AnalogRead::usage = "AnalogRead[ pin ] returns the analog pin readout from the specified pin on an Arduino device.";

ArduinoRun::usage = "ArduinoRun[fun_, {arg1, arg2, ...}] runs the specified function on the Arduino device with the given arguments.";   
ArduinoInstallConnectModule::usage = "ArduinoInstallConnectModule[module_] installs the module with the specified name into the ArduinoConnect environment.";

ArduinoGetConnectModules::usage = "ArduinoGetConnectModules[] returns a list of connect modules that can be loaded into ArduinoConnect.";
GenerateArduinoConnectLibrary
ArduinoConnectLibrary
ArduinoConnectInput
ArduinoConnectOutput

(****************************************************************************************************
 *	Serial (same symbols for both computer and device)				    							*
 ****************************************************************************************************)

ArduinoSerialBegin::usage = "ArduinoSerialBegin[arduino] opens a serial connection with the specified Arduino device.";
ArduinoSerialEnd::usage = "ArduinoSerialEnd[arduino] closes the serial connection with the specified Arduino device.";
ArduinoSerialWrite::usage = "ArduinoSerialWrite[arduino, value] writes a value as serial data to the Arduino.";
ArduinoSerialWriteByte::usage = "ArduinoSerialWriteByte[arduino, charCode] writes a byte specified by the given character code to the Arduino.";
ArduinoSerialRead::usage = "ArduinoSerialRead[arduino] returns the next token of data read from the Arduino.";
ArduinoSerialBufferSize::usage = "ArduinoSerialBufferSize[arduino] returns the size of the serial buffer for the specified Arduino device.";
ArduinoSerialAvailableQ::usage = "ArduinoSerialAvailableQ[arduino] returns true if there is data available to be read from the ArduinoLink serial buffer.";
ArduinoSerialFlush::usage = "ArduinoSerialFlush[arduino] flushes the ArduinoLink serial buffer in Mathematica.";

(****************************************************************************************************
 *	Servo motor interface 											    							*
 ****************************************************************************************************)
ArduinoServoAttach::usage = "";
ArduinoServoWrite::usage = "";
ArduinoServoRead::usage = "";
ArduinoServoDetach::usage = "";

(****************************************************************************************************
 *	SPI (Serial Peripheral Interface)											    				*
 ****************************************************************************************************)
ArduinoSPIPins::usage = "";
ArduinoSPIInterrupt::usage = "";
ArduinoSPIBeginMaster::usage = "";
ArduinoSPIBeginSlave::usage = "";
ArduinoSPISlaveWriteBuffer::usage = "";

(****************************************************************************************************
 *	Serial slave interface 											    							*
 ****************************************************************************************************)
ArduinoConnect::usage = "ArduinoConnect[arduino] connects Mathematica to the symbolic Arduino device.";
ArduinoDigitalWrite::usage = "ArduinoDigitalWrite[port, val] writes the value to the given digital port on the Arduino device connected from ArduinoConnect.";
ArduinoDigitalRead::usage = "ArduinoDigitalRead[port] returns the digital value of the given port on the Arduino device connected from ArduinoConnect.";
ArduinoAnalogWrite::usage = "ArduinoAnalogWrite[port, val] writes the given value to the given analog port on the Arduino device connected from ArduinoConnect.";
ArduinoAnalogRead::usage = "ArduinoAnalogRead[port] returns the analog reading of the given port on the Arduino device connected from ArduinoConnect.";

(****************************************************************************************************
 *	Other Arduino functions																			*
 ****************************************************************************************************)

ArduinoWait::usage = "ArduinoWait[ millis ] instructs an Arduino device to wait for the specified time in milliseconds.";

(****************************************************************************************************
 *	Error messages																					*
 ****************************************************************************************************)

ArduinoLink::upload = "The generated sketch was not able to be uploaded onto the Arduino device. `1`";
ArduinoLink::support = "ArduinoLink does not support `1`";
ArduinoLink::notfound = "No Arduino device was found at `1`."
ArduinoLink::noserial = "No serial connection is established to the specified device.";
ArduinoLink::dependency = 
"ArduinoLink dependencies: \n \
 - version 0022 of the Arduino IDE in /Applications (http://arduino.cc/en/Main/Software) \n \
 - FTDI USB Serial Driver - ships with the Arduino IDE (http://arduino.cc/en/Main/Software) \n \
 - CrossPack version 20100115 for AVR Development (http://www.obdev.at/products/crosspack/download.html) \n \
 Wolfram Research Inc. is not affiliated with any of these third-party software providers.";
ArduinoLink::init = "An Arduino microcontroller must be connected in order to proceed with initialization.";
ArduinoLink::noinit = "ArduinoLink failed to initialize.";

(* Constants *)
High
Low
Analog
Digital

$CurrentArduino

Begin["`Private`"]

(* Dependency tests. Ensures that the Arduino IDE is installed in the user's Applications directory,
   and checks for CrossPack availability.															 *)
If[ Not[ FileExistsQ["/Applications/Arduino.app"]], Message[ArduinoLink::dependency] ];
If[ Not[ FileExistsQ["/usr/local/CrossPack-AVR"]], Message[ArduinoLink::dependency] ];

(* Directory constants *)
$MyPackageDirectory = DirectoryName[System`Private`$InputFileName];
$ArduinoIDEDirectory = "/Applications/Arduino.app/Contents/Resources/Java";

(* Loads the package version of SerialIO for OSX *)
If[ Not[ MemberQ[$Path, $MyPackageDirectory]],
	AppendTo[$Path, $MyPackageDirectory]];
If[ Length[Names["SerialIO`*"]] == 0,
	Get["SerialIO`"];
]

(* Global ArduinoConnect data *)
$CurrentArduino
$ArduinoConnectActive = False;
$ArduinoConnectModules = {};
$ArduinoConnectCommandBlockingMap = {};
$ArduinoConnectCommandNames = {};
$ArduinoConnectGlobal = {};
$ArduinoConnectFunctionMap = {};

(*  Creates a map from file descriptors to SerialPort objects, and a map from
	file descriptors to string buffers where serial input data is stored. *)
If[Not[ ValueQ[$ArduinoSerialPortMap] ], $ArduinoSerialPortMap = { } ];
If[Not[ ValueQ[$ArduinoSerialBuffer] ], $ArduinoSerialBuffer = { } ];

(* External constants *)
Low = "LOW";
High = "HIGH"; 

(* Internal data for code generation *)
$ArduinoSymbolTable = {};
$ArduinoWritePins = {};
$ArduinoReadPins = {};
$ArduinoBaudRate = 9600;
$ArduinoIncludeLibraries = {"WProgram.h"};

(* Maps code generation functions to their SymbolicC representations. Appending to this list is the easiest
   way to add a new code generation symbol. *)
$ArduinoToSymbolicC = {
	(* Abstraction of common C constructs *)
	ArduinoRepeat[ var_, range_List, block_] :> 
		CBlock[{CDeclare["int", var], 
			CFor[CAssign[var, First[range]], 
				 COperator[If[First[range] < Last[range], LessEqual, GreaterEqual], {var, Last[range]}], 
				 COperator[If[First[range] < Last[range], Increment, Decrement], {var}], 
				block]}],
				
	(* Digital/Analog IO *)
	AnalogRead[ pin_ ] -> CCall["analogRead", {pin}],
	DigitalRead[ pin_ ]	->  CCall["digitalRead", {pin}],
	AnalogWrite[ pin_, value_ ] :> If[ ListQ[pin], CCall["analogWrite", {#, value}] & /@ pin, CCall["analogWrite", {pin, value}]],
	DigitalWrite[ pin_ , value_ ] :> If[ ListQ[pin], CCall["digitalWrite", {#, value}] & /@ pin, CCall["digitalWrite", {pin, value}]],
	
	(* Abstractions of Common I/O - will increase in time *)
	DigitalBlink[ pin_, time_ ] :> If[ ListQ[pin], DigitalBlink[#, time] & /@ pin, 
									CBlock[ {DigitalWrite[pin, High], ArduinoWait[time],
											DigitalWrite[pin, Low], ArduinoWait[time]}]],
	SquareWave[pin_] -> DigitalBlink[pin, 1],				
	
	(* Pin naming functions and pin declarations *)						
	ArduinoSetPin[ pin_, type_ ] -> CCall["pinMode", {pin, type}],
	ArduinoNamePin[pin_, name_] -> CComment["\npreprocessor globally names pins\n"],
	ArduinoSetPin[pin_, iotype_] -> CCall["pinMode",{pin,iotype}],
	
	(* Miscellaneous Arduino functions *)
	ArduinoWait[ millis_ ] :> CCall["delay", {millis}],
	ArduinoWaitMicroseconds[ us_ ] :> CCall["delayMicroseconds", {us}],
	
	(* Arduino Serial functions *)
	ArduinoSerialBegin[] :> CMember["Serial", CCall["begin", { $ArduinoBaudRate }]],
	ArduinoSerialEnd[] -> CMember["Serial", CCall["end", { }]],
	ArduinoSerialAvailableQ[] -> COperator[Greater, { ArduinoSerialBufferSize[], 0 }],
	ArduinoSerialBufferSize[] -> CMember["Serial", CCall["available", {} ] ],
	ArduinoSerialFlush[] -> CMember["Serial", CCall["flush", {} ] ],
	ArduinoSerialWrite[val_] :> CCall["_aux_sendPacket", {val}],
	(*ArduinoSerialWrite[val_] :> CMember["Serial", CCall["print", {val}]],*)
	ArduinoSerialWriteByte[byte_] :> CMember["Serial", CCall["write", {byte}]],
	ArduinoSerialRead[] -> CMember["Serial", CCall["read", {}]],
	
	(* Arduino Servo library functions *)
	ArduinoServoAttach[servo_, pin_] -> CMember[servo, CCall["attach", {pin}]], 
	ArduinoServoWrite[servo_, val_] -> CMember[servo, CCall["write", {val}]],
	
	(* Arduino SPI library functions *)
	ArduinoSPIPins[ss_, mosi_, miso_, sck_] :> MapThread[CDefine[#1, #2] &, {{"SS", "MOSI", "MISO", "SCK"}, {ss, miso, mosi, sck}}], 
	ArduinoSPIBeginSlave[] -> {
				CAssign["spi_buffer_pos", 0],
				CAssign["spi_slave_process", "false"],
				CCall["pinMode", {"SS", "OUTPUT"}],
				CCall["pinMode", {"MISO", "OUTPUT"}],
				CAssign["SPCR", COperator[BitOr, {"SPCR", "_BV(SPE)"}]],
				CCall[CMember["SPI", "setBitOrder"], {"MSBFIRST"}],
				CCall[CMember["SPI", "attachInterrupt"], {}]},
	ArduinoSPISlaveWriteBuffer[] -> {
		
	},
	ArduinoSPIInterrupt[] -> CFunction["ISR", "", {"SPI_STC_vect"}, {
		CDeclare["byte", CAssign["b", "SPDR"]], 
  		CIf[COperator[Less, {"spi_buffer_pos", 100}], 
   		CAssign[CArray["spi_buffer", "spi_buffer_pos"], "b"], 
   		CAssign["spi_slave_process", "true"]], 
  		CIf[COperator[Equal, {"b", "'\\n'"}], 
   		CAssign["spi_slave_process", "true"]]}]
}

(****************************************************************************************************
 *	ARDUINOLINK USER FUNCTIONS FOR LINKING A DEVICE 												*
 ****************************************************************************************************)

$TTYPREFIXES = {"tty.usbserial*", "tty.usbmodem*"}

Options[LinkArduino] = {
	"Microcontroller" -> "Uno", 
	"UploadSpeed" -> 115200, 
	"BaudRate" -> 9600, 
	"UploadProtocol" -> "stk500v1"};

$Arduino = {
	(* Most recent Arduino boards *)
	"Uno" -> 			{"atmega328p", 115200, 16},
	"Duemilanove" -> 	{"atmega328p", 57600, 16},
	"Mega" ->			{"atmega2560", 115200, 16},
	"Mini" ->			{"atmega168", 19200, 16},
	"Fio" ->			{"atmega328p", 57600, 8},
	"BT" ->				{"atmega328p", 19200, 16},
	"LilyPad" ->		{"atmega328p", 57600, 8},
	"Pro" ->			{"atmega328p", 57600, 16},
	"Pro Mini" ->		{"atmega328p", 57600, 16},
	"NG" ->				{"atmega168", 19200, 16},
	(* Older Arduino boards *)
	"Duemilanove w/ ATmega168" -> 	{"atmega168", 19200, 16},
	"Mega w/ ATmega1280" -> 		{"atmega1280", 57600, 16},
	"BT w/ ATmega168" -> 			{"atmega168", 19200, 16},
	"LilyPad w/ ATmega168" -> 		{"atmega168", 19200, 8},
	"Pro w/ ATmega168" -> 			{"atmega168", 19200, 16},
	"Pro Mini w/ ATmega168" -> 		{"atmega168", 19200, 16},
	"Pro 3.3V w/ ATmega328" ->		{"atmega328p", 57600, 8},
	"Pro 3.3V w/ ATmega168" -> 		{"atmega168", 19200, 8},
	"NG w/ ATmega8" -> 				{"atmega8", 19200, 16}
}

$SupportedArduino = First /@ $Arduino;
$SupportedMicrocontroller = DeleteDuplicates[First[# /. $Arduino] & /@ $SupportedArduino]

LinkArduino[OptionsPattern[]] := 
	LinkArduino[#, OptionValue["Microcontroller"], 
		OptionValue["UploadProtocol"], OptionValue["BaudRate"]] & /@ FileNames[$TTYPREFIXES, {"/dev/"}]
	
LinkArduino[port_String, microcontroller_String : "Uno", protocol_ : "stk500v1", baud_ : 9600] :=
(	$ArduinoBaudRate = baud;
	If[ MemberQ[ FileNames[$TTYPREFIXES, {"/dev/"} ], port ],
		If[MemberQ[ $SupportedArduino, microcontroller] || MemberQ[ $SupportedMicrocontrollers, microcontroller ],
			Arduino[port,
				If[MemberQ[$SupportedArduino, microcontroller], First[microcontroller /. $Arduino], microcontroller],
				If[MemberQ[$SupportedArduino, microcontroller], (microcontroller /. $Arduino)[[2]], 57600],
				If[MemberQ[$SupportedArduino, microcontroller], (microcontroller /. $Arduino)[[3]], 16],
				baud],
			Message[ArduinoLink::support, microcontroller]; $Failed
		],
		Message[ArduinoLink::notfound, port]; $Failed
	])

(****************************************************************************************************
 *	ARDUINOLINK USER FUNCTIONS FOR COMPILING/EXECUTING ON A DEVICE 									*
 ****************************************************************************************************)

ArduinoUpload[ device_Arduino ] := ArduinoConnect[device]

ArduinoUpload[ device_Arduino, loop_List ] := ArduinoUpload[device, {}, {}, loop]

ArduinoUpload[ device_Arduino, setup_List, loop_List ] := ArduinoUpload[device, {}, setup, loop]

ArduinoUpload[ device_Arduino, predecl_List, setup_List, loop_List ] := 
	If[ ArduinoQ[device], 
		ArduinoUploadC[device, ArduinoGenerateC[predecl, setup, loop]],
		Message[ArduinoLink::notfound,First[device]]
	]

(****************************************************************************************************
 *	ARDUINOLINK USER FUNCTIONS FOR READING AND WRITING TO A DEVICE									*
 ****************************************************************************************************)

ArduinoSerialBegin[arduino_Arduino] := 
Module[ { com },
	If[ Not[ ArduinoSerialOpenQ[ arduino ] ],
		com = SerialOpen[ First[arduino], "BaudRate" -> Last[arduino] ];
		If [ com === $Failed,
			$Failed,
			AppendTo[$ArduinoSerialPortMap, {First[arduino], com } ];
			AppendTo[$ArduinoSerialBuffer, {First[arduino], "" } ];
		]
	]
]

ArduinoSerialEnd[arduino_Arduino] :=  
	If[ Not[ ArduinoGetSerialPort[arduino] === $Failed ],
		SerialClose[ArduinoGetSerialPort[arduino]];
		$ArduinoSerialPortMap = Select[ $ArduinoSerialPortMap, First[#] != First[arduino] &];
		$ArduinoSerialBuffer = Select[ $ArduinoSerialBuffer, First[#] != First[arduino] &];
		, $Failed
	]

ArduinoGetSerialPort[arduino_Arduino] :=
	Module[ {serialdevices},
	serialdevices = Flatten[Select[ $ArduinoSerialPortMap, First[#] == First[arduino] &]];
	If[ Length[serialdevices] != 0, 
		Last[serialdevices], $Failed]
	]

ArduinoSerialRead[arduino_Arduino] :=
(	If[ ArduinoQ[arduino],
		If[ Not[ArduinoSerialOpenQ[arduino]],
			ArduinoSerialBegin[arduino]
		];
		ArduinoSerialReadBuffer[arduino];
		ArduinoSerialNext[arduino],
	Message[ArduinoLink::notfound, First[arduino]]; $Failed]
)

ArduinoSerialReadBuffer[arduino_] :=
	Module[ {com = ArduinoGetSerialPort[arduino]},
		While[ SerialReadyQ[com], 
			ArduinoSerialAddToBuffer[arduino, SerialRead[com, 1]]
		];
	]

ArduinoSerialNext[arduino_Arduino] := 
	If[ArduinoSerialAvailableQ[arduino],
	Module[
	 	{serialBuffer = ArduinoSerialGetBuffer[arduino], next, elem},
	 	next = StringCases[serialBuffer, Shortest["!!" ~~ data__ ~~ "$$"] -> data, 1];
	 	If[Length[next] == 1,
	 		elem = FromDigits[StringCases[First[next], DigitCharacter ..]];
	 		ArduinoSerialSetBuffer[arduino, StringReplace[serialBuffer, Shortest["!!" ~~ __ ~~ "$$"] ~~ rest___ :> rest, 1]];
	 		elem
	 	]
	]]

ArduinoSerialAvailableQ[arduino_Arduino] := 
	If[ ArduinoQ[arduino],
		If[ Not[ArduinoSerialOpenQ[arduino]],
			ArduinoSerialBegin[arduino]
		];
		ArduinoSerialReadBuffer[arduino];
		StringMatchQ[ArduinoSerialGetBuffer[arduino], "!!" ~~ __ ~~ "$$"]
	]

ArduinoSerialWrite[arduino_Arduino, val_] :=
	If[ ArduinoQ[arduino],
		If[ Not[ArduinoSerialOpenQ[arduino]],
			ArduinoSerialBegin[arduino]
		];
		SerialWrite[ArduinoGetSerialPort[arduino], ToString[val]];
		(*SerialWrite[ArduinoGetSerialPort[arduino], #] & /@ Flatten[ToCharacterCode /@ Characters[ToString[val]]];*)
	,
	Message[ArduinoLink::notfound, First[arduino]]; $Failed]

ArduinoSerialGetBuffer[arduino_Arduino] := Block[ {buffer},
	If[ (buffer = Flatten[Select[$ArduinoSerialBuffer, First[#] == First[arduino] &]]) === {}, "", buffer[[2]]]
]

ArduinoSerialSetBuffer[arduino_Arduino, buff_] := 
(	pos = First[Flatten[Position[$ArduinoSerialBuffer, First[arduino]]]];
	$ArduinoSerialBuffer = 
		ReplacePart[ $ArduinoSerialBuffer, 
			pos :> { First[arduino], buff }];
)

ArduinoSerialAddToBuffer[arduino_Arduino, buff_] := 
(	pos = First[Flatten[Position[$ArduinoSerialBuffer, First[arduino]]]];
	$ArduinoSerialBuffer = 
		ReplacePart[ $ArduinoSerialBuffer, 
			pos :> { First[arduino], StringJoin[$ArduinoSerialBuffer[[pos, 2]], buff] }];
)

ArduinoSerialDeleteFromBuffer[arduino_Arduino, length_] := 
(	pos = First[Flatten[Position[$ArduinoSerialBuffer, First[arduino]]]];
	$ArduinoSerialBuffer = 
		ReplacePart[ $ArduinoSerialBuffer, 
			pos :> { First[arduino], StringDrop[$ArduinoSerialBuffer[[pos, 2]], length] }];
)

ArduinoSerialFlushBuffer[arduino_Arduino] :=
(	pos = Flatten[Position[$ArduinoSerialBuffer, First[arduino]]];
	If[ pos != {}, $ArduinoSerialBuffer[[pos, 2]] = ""];	
)

ArduinoSerialOpenQ[arduino_Arduino] := ( ArduinoQ[arduino] && MemberQ[$ArduinoSerialPortMap, First[arduino], {2}] )

(****************************************************************************************************
 *	ARDUINO CODE GENERATION FUNCTIONS																*
 ****************************************************************************************************)

ArduinoGenerateC[predecl_List, setup_List, loop_List] := 
(	ArduinoSetPinModes[predecl,setup,loop];
	ToCCodeString[
	ArduinoGenerateSymbolTable[
		CProgram @@
		Flatten[{ 
			ArduinoPreprocess[predecl, setup, loop],
			ArduinoGenerateSetup[predecl, setup, loop],
			ArduinoGenerateLoop[loop],
			ArduinoGenerateFunctions[predecl]
		}]
	]
	]
)

ArduinoPreprocess[ predecl_, setup_, loop_] :=
(
	ArduinoGenerateSymbolTable[Join[predecl, setup, loop]];
	ArduinoGenerateDependencies[predecl, setup, loop];
	Join[ 
		CInclude /@ Join[$ArduinoIncludeLibraries],
		{ (* includes and preprocessor *)
		  SelectSymbolsWithHead[predecl, {CInclude}, 1],
		  (* function headers *)
		  ArduinoGenerateFunctionHeaders[predecl],
		  ArduinoGenerateAuxilaryFunctions[Join[predecl, setup, loop]],
		  (* global variables *)
		  ArduinoGenerateNamedPins[predecl, setup, loop],
		  ArduinoGenerateVarDecls[predecl, setup, loop],
		  (* acceptable SymbolicC statements *)
		  SelectSymbolsWithHead[Flatten[predecl //. $ArduinoToSymbolicC], {CDeclare, CStatement}, 1] 
		}
	]
)

ArduinoGenerateCCode[arduinocode_] := 
	arduinocode //. $ArduinoToSymbolicC

ArduinoGenerateSetup[predecl_, setup_, loop_] :=
	CFunction["void", "setup", {}, Flatten[
  		ArduinoGenerateCCode 
  			/@	{ArduinoGeneratePreprocessorSetup[predecl, setup, loop], setup }
  		]]

ArduinoGenerateLoop[loop_List] := 
	CFunction["void", "loop", {}, ArduinoGenerateCCode[loop] ]

ArduinoGenerateFunctions[predecl_List] :=
	Map[ CFunction[ #[[1]],#[[2]],#[[3]], 
		ArduinoGenerateCCode[ Drop[Level[#, 1], 3] ] ] &, 
		SelectSymbolsWithHead[predecl,{CFunction}] ]
	
ArduinoGenerateAuxilaryFunctions[code_List] := 
	If[Length[SelectSymbolsWithHead[code, {ArduinoSerialWrite}]] > 0,
		ArduinoSerialAuxilaryFunctions[],
		{}
	]

ArduinoGeneratePinModes[] :=
	CCall["pinMode", {#, "OUTPUT"}] & /@ $ArduinoWritePins

ArduinoGeneratePreprocessorSetup[predecl_, setup_, loop_] := 
	Module[ {test = {}, gen = {}},
		test = ArduinoGeneratePinModes[];
		If[test != {}, AppendTo[gen, test]];
		test = SelectSymbolsWithHead[Join[ predecl, setup, loop ], {ArduinoSerialWrite, ArduinoSerialRead}];
		If[test != {}, AppendTo[gen, ArduinoSerialBegin[]]];
		gen
	]

ArduinoGeneratePreprocessorLoop[predecl_, setup_, loop_] := 
	Module[ {test = {}, gen = {}},
		test <> gen
	]

ArduinoGenerateNamedPins[predecl_, setup_, loop_] := 
	Module[ {pinnamedecls},
	pinnamedecls = Select[ Level[Join[ predecl, setup, loop ], {0, Infinity}], (Head[#] == ArduinoNamePin) &];
	CDeclare["int", CAssign[#[[2]], #[[1]] ]] & /@ pinnamedecls
]

ArduinoGenerateDependencies[predecl_, setup_, loop_] :=
	Module[ {headers = {}},
	If[ SelectSymbolsWithHead[Join[ predecl, setup, loop ], {ArduinoServoWrite, ArduinoServoRead, ArduinoServoAttach}] != {}, 
		AppendTo[$ArduinoIncludeLibraries, CInclude["Servo.h"]]];
	headers
]

ArduinoGenerateVarDecls[predecl_, setup_, loop_] :=
	Module[ {test, vardecls = {}},
	test = Select[ Level[Join[ predecl, setup, loop ], {0, Infinity}], (Head[#] == ArduinoServoAttach) &];
	If[ test != {},
		test = First /@ test;
		AppendTo[vardecls, CDeclare["Servo", #] & /@ test];
		AppendTo[$ArduinoSymbolTable, {"Servo", #}] & /@ test;
	];
	vardecls
]

ArduinoGenerateFunctionHeaders[predecl_] := 
	Flatten[ Join[{ CFunction["void","loop",{}], CFunction["void","setup",{}] },
		Map[ CFunction[#[[1]],#[[2]],#[[3]]] &, Select[ predecl, Head[#] == CFunction & ] ]
	]]

ArduinoGenerateSymbolTable[block_] := 
(	AppendTo[$ArduinoSymbolTable, Take[Level[#, {1, 2}], 2]] & /@ 
   		Select[Level[block, {0, Infinity}], (Head[#] == CDeclare) &]; block)

ArduinoSetPinModes[predecl_, setup_, loop_] := 
( 	$ArduinoWritePins = Select[ DeleteDuplicates[Cases[
		( Level[Flatten[Select[
			Level[Join[ predecl, setup, loop ], {0, Infinity}], 
			(MemberQ[{DigitalWrite, AnalogWrite, ArduinoWrite, DigitalBlink}, Head[#]]) &]], {2, 3}]
		[[1;;All;;2]] ), _Integer | _String]], Not[MemberQ[{High,Low}, #]] & ];
   		
  	$ArduinoReadPins = {#, INPUT} & /@ DeleteDuplicates[
 			Flatten[Level[Select[Level[Join[predecl, setup, loop], {0, Infinity}], 
   			(Head[#] == DigitalRead || Head[#] == AnalogRead || Head[#] == ArduinoRead) &], {2}]]];
)

SelectSymbolsWithHead[source_List, head_List, maxLevel_ : Infinity] := Select[ Level[source, {0, maxLevel}], MemberQ[head, Head[#]] &] 


(****************************************************************************************************
 *  ARDUINOLINK LIBRARY GENERATION																	* 
 ****************************************************************************************************)

GenerateArduinoConnectLibrary[globals_, functionMap_, setup_:{ }] := 
	ArduinoConnectLibrary[ GenerateFunctionCommands[functionMap], 
		globals, GenerateConnectFunctions[globals, functionMap] ]

GenerateFunctionCommands[functionMap_] := 
	(First[#] -> (Length[SelectSymbolsWithHead[Last[#], {ArduinoConnectOutput}]] > 0) ) & /@ functionMap 

GenerateConnectFunctions[globals_, functionMap_] :=
	Module[ { symbolTable = (Level[#, 1] & /@ SelectSymbolsWithHead[globals, {CDeclare}]) },
		CFunction["void", First[#], {}, Last[#] /.	{
			ArduinoConnectInput[var_String] :> 
				If[MemberQ[symbolTable, var, {2}],
					CAssign[var, CCall["_next" <> Select[symbolTable, Last[#] == var &][[1,1]], {}]],
					CStatement[""]	
				],
			ArduinoConnectOutput[var_String] :>
				If[MemberQ[symbolTable, var, {2}],
					CCall["_send" <> Select[symbolTable, Last[#] == var &][[1,1]], {var}],
					CStatement[""]
				]	
   			}] & /@ functionMap
	]

ArduinoInstallConnectModule[module_String, args_List : { }] := 
	If[ Not[ MemberQ[$ArduinoConnectModules, module] ] && MemberQ[ArduinoGetConnectModules[], module],
		AppendTo[$ArduinoConnectModules, module];
		Get[ FileNameJoin[{ $MyPackageDirectory, "ConnectModules", module <> ".m" }]];
		library = Symbol[module][args];
		If[ Head[library] === ArduinoConnectLibrary,
			AppendTo[$ArduinoConnectCommandBlockingMap, #] & /@ First[library];
			AppendTo[$ArduinoConnectCommandNames, First[#]] & /@ First[library];
			AppendTo[$ArduinoConnectGlobal, #] & /@ library[[2]];
			AppendTo[$ArduinoConnectFunctionMap, #] & /@ Last[library];
			DeleteDuplicates /@ {$ArduinoConnectCommandNames, $ArduinoConnectGlobal, $ArduinoConnectFunctionMap};,
			$Failed
		]];

ArduinoGetConnectModules[] := StringDrop[#, -2] & /@ (FileNameTake /@ 
   FileNames[FileNameJoin[{$MyPackageDirectory, "ConnectModules", "*"}]])

ArduinoInstallConnectModule["Serial", {}];
ArduinoInstallConnectModule["PinIO", {}];

(****************************************************************************************************
 *  ARDUINO CONNECT FUNCTIONS																		* 
 ****************************************************************************************************)

Options[ArduinoConnect] = {"Include" -> {}}

ArduinoConnect[arduino_Arduino, OptionsPattern[]] :=
(	$CurrentArduino = arduino;
	$ArduinoConnectActive = True;
	Map[(ArduinoInstallConnectModule @@ #) &, OptionValue["Include"]];
	ArduinoUpload @@ Join[{arduino}, ArduinoConnectGenerate[]];
	ArduinoDigitalWrite[13,Low];
	Pause[1];
	ArduinoDigitalWrite[13,High];
	Pause[1];
	ArduinoDigitalWrite[13, Low];
)

ArduinoConnectFunctionCode[function_] :=
	If[ MemberQ[$ArduinoConnectCommandNames, function], 
		32 + Position[$ArduinoConnectCommandNames, function][[1,1]], 32]

ArduinoRun[function_String, args_List : { }] :=
	Refresh[PreemptProtect[( 
	If[ArduinoQ[$CurrentArduino] && MemberQ[$ArduinoConnectCommandNames, function],
		ArduinoSerialWrite[$CurrentArduino, 
			FromCharacterCode[ArduinoConnectFunctionCode[function]] <>
			StringJoin[ ( ToString[#] <> "/" & /@ args ) ]];
		If[function /. $ArduinoConnectCommandBlockingMap,
			While[Not[ArduinoSerialAvailableQ[$CurrentArduino]]];
			ToExpression@ArduinoSerialRead[$CurrentArduino]
		],
		$Failed	
	])], None]

ArduinoConnectGenerate[] := {Join[$ArduinoConnectFunctionMap, $ArduinoConnectGlobal], {ArduinoSerialBegin[]}, 
	Join[ {	CDeclare["char", CAssign["command", CCall["_nextchar", {}]]] },
 		{	MapThread[CIf[COperator[Equal, {"command", #1}], #2] &,
  			{ArduinoConnectFunctionCode /@ $ArduinoConnectCommandNames,
  			CCall[#, {}] & /@ $ArduinoConnectCommandNames}
     	]}]
	}

ArduinoDigitalWrite[port_, value_] := ArduinoRun["ArduinoDigitalWrite", {port, If[value == Low, 0, 1]}]

ArduinoDigitalRead[port_] := ArduinoRun["ArduinoDigitalRead", {port}]

ArduinoAnalogWrite[port_, value_] := ArduinoRun["ArduinoAnalogWrite", {port, value}]

ArduinoAnalogRead[port_] := ArduinoRun["ArduinoAnalogRead", {port}]

(****************************************************************************************************
 *	ERROR-CHECKING FUNCTIONS
 ****************************************************************************************************)

ArduinoQ[arduino_Arduino] := MemberQ[LinkArduino[], arduino] && Length[Level[arduino, 1]] == 5
ArduinoQ[arduino_] := False

(****************************************************************************************************
 *	UPLOADING .CPP FILES TO THE ARDUINO BOARD														*
 ****************************************************************************************************)

ArduinoUploadC[arduino_, sketch_String] := 
Module [ {curdir, fname, success},
	(* Ensure the serial port is closed before uploading *)
	If[ ArduinoSerialOpenQ[arduino] == True,
		ArduinoSerialEnd[arduino];
		ArduinoSerialFlushBuffer[arduino];
	];
	
	(* Set up a build in a temporary directory *)
	curdir = Directory[];
	fname = CreateDirectory[];
	CopyFile[ FileNameJoin[{ $MyPackageDirectory, "Makefile" }], FileNameJoin[{fname, "Makefile"}]];
	SetDirectory[fname];
	dbPrint[fname];
	Export["device", ArduinoDeviceSpecification[arduino], "String"];
	Export["environment", ArduinoEnvironmentSpecification[arduino], "String"];
	Export[StringJoin[ FileNameTake[fname], ".cpp" ], sketch, "String"];
	
	(* Execute the build and upload it to the device *)
	success = Run["/usr/local/CrossPack-AVR/bin/make"];
	success = Run["/usr/local/CrossPack-AVR/bin/make upload"];
	
	(* Delete temp directory and return *)
	SetDirectory[ParentDirectory[]];
	(*DeleteDirectory[fname, DeleteContents -> True];*)
	SetDirectory[curdir];
	If [ success != 0, Message[ArduinoLink::upload, fname]];
]

(****************************************************************************************************
 *	ARDUINO DEVICE/ENVIRONMENT FUNCTIONS															*
 ****************************************************************************************************)

ArduinoDeviceSpecification[arduino_] :=
	" ARDUINO_PORT ?= "<> arduino[[1]] <> "\n" <>
	" ARDUINO_UPLOAD_RATE ?= "<> ToString[arduino[[3]]] <> " \n" <>
	" ARDUINO_AVRDUDE_PROGRAMMER ?= stk500v1 \n" <>
	" ARDUINO_MCU ?= "<> arduino[[2]] <>" \n" <>
	" ARDUINO_F_CPU ?= "<> ToString[arduino[[4]]] <>"000000\n"

ArduinoEnvironmentSpecification[arduino_] :=
	" INSTALL_DIR = " <> $ArduinoIDEDirectory <>"\n" <>
	" ADDON_LIB_DIR = "<> FileNameJoin[{$MyPackageDirectory, "ConnectLibraries"}]

(****************************************************************************************************
 *	OTHER FUNCTIONS																					*
 ****************************************************************************************************)
 
FromRealDigits[n_] := 
	With[{strnum = StringSplit[n, "."]}, 
  		N[  (* value *) FromDigits[First[strnum]] + FromDigits[Last[strnum]] / 10^StringLength[Last[strnum]],
   			(* precision *) StringLength[n] - 1]]

(****************************************************************************************************
 *	INITIALIZATION LOGIC																			*
 ****************************************************************************************************)

InitializeArduinoLink[] :=
Module [ {curdir, fname, success, arduino = LinkArduino[], sketch = ArduinoGenerateC[{},{},{}]},
	If[Length[arduino] == 0, Message[ArduinoLink::init],
		arduino = First[arduino];
		(* Ensure the serial port is closed before uploading *)
		If[ ArduinoSerialOpenQ[arduino] == True,
			ArduinoSerialEnd[arduino];
			ArduinoSerialFlushBuffer[arduino];
		];
		(* Ensures that builds work properly *)
		curdir = Directory[];
		fname = CreateDirectory[];
		CopyFile[ FileNameJoin[{ $MyPackageDirectory, "Makefile" }], FileNameJoin[{fname, "Makefile"}]];
		SetDirectory[fname];
		Export["device", ArduinoDeviceSpecification[arduino], "String"];
		Export["environment", ArduinoEnvironmentSpecification[arduino], "String"];
		Export[StringJoin[ FileNameTake[fname], ".cpp" ], sketch, "String"];
		success = 1;
		timeout = 0;
		(* Execute the build and upload it to the device, repeating if Arduino IDE has uncompiled errors *)
		While[success != 0 && timeout < 100,
			success = Run["/usr/local/CrossPack-AVR/bin/make"];
			success = Run["/usr/local/CrossPack-AVR/bin/make upload"];
			timeout++;
		];
		(*Print[fname];
		Print@Import["!/usr/local/CrossPack-AVR/bin/make", "TEXT"];
		For[i = 0, i<100, i++,
			Print@Import["!/usr/local/CrossPack-AVR/bin/make", "TEXT"];
			Print@Import["!/usr/local/CrossPack-AVR/bin/make upload", "TEXT"];
		];*)
		If[timeout == 100, Message[ArduinoLink::noinit]];
		(* Delete temp directory and return *)
		SetDirectory[ParentDirectory[]];
		DeleteDirectory[fname, DeleteContents -> True];
		SetDirectory[curdir];
	];
]

End[]

EndPackage[]